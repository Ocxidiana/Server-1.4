import bs
#creted by Blitz Modders
#Join Our Squad Now
#You Will Need ChatReply.py From Our Repository
#You Can Add Any Ammount Of Msg Just type
#Msg List
allow = True

messageList = ['Join in our Discord server by clicking stats']
#Msg Timer 
chatMessageTime = 180000 #seconds
#Change According To U

#colors
#thanks to google
#Black (0,0,0)
#White (2.55,2.55,2.55)
#Red (2,0,0)
#Lime (0,2.55,0)
#Blue (0,0,2.55)
#Yellow (2.55,2.55,0)
#Cyan / Aqua (0,2.55,2.55)
#Magenta / Fuchsia (2.55,0,2.55)
#Silver (1.92,1.92,1.92)
#Gray (1.28,1.28,1.28)
#Maroon (1.28,0,0)
#Olive (1.28,128,0)
#Green (0,1.28,0)
#Purple (1.28,0,1.28)
#Teal (0,1.28,1.28)
#Navy (0,0,1.28)
