#Maded by Froshlee14
import bs
import random
import bsPowerup
from bsPowerup import PowerupFactory,_TouchedMessage,PowerupMessage,PowerupAcceptMessage,defaultPowerupInterval
import bsUtils
import bsSpaz
from bsSpaz import *

class PlayerSpaz_Speller(bs.PlayerSpaz):
    def __init__(self,color=(1,1,1),highlight=(0.5,0.5,0.5),character="Spaz",player=None,powerupsExpire=True):
        if player is None: player = bs.Player(None)
        Spaz.__init__(self,color=color,highlight=highlight,character=character,sourcePlayer=player,startInvincible=True,powerupsExpire=powerupsExpire)
        self.lastPlayerAttackedBy = None
        self.lastAttackedTime = 0
        self.lastAttackedType = None
        self.heldCount = 0
        self.lastPlayerHeldBy = None
        self._player = player

        if player.exists():
            playerNode = bs.getActivity()._getPlayerNode(player)
            self.node.connectAttr('torsoPosition',playerNode,'position')
		
        m = bs.newNode('math', owner=self.node, attrs={'input1': (0, 1.1, 0), 'operation': 'add'})
        self.node.connectAttr('position', m, 'input2')
        self._text = bs.newNode('text',owner=self.node,attrs={'text':'','inWorld':True,'shadow':1.0,
                                'flatness':1.0,'color':(1,1,1),'scale':0.0,'hAlign':'center','maxWidth':200})
        m.connectAttr('output', self._text, 'position')
        bs.animate(self._text, 'scale', {0: 0.0, 100: 0.02})
		
    def delText(self):
        self._text.text = ''

    def handleMessage(self,m):
        if isinstance(m,NewPowerupMessage):
            if self._dead: return True
            if self.pickUpPowerupCallback is not None:
                self.pickUpPowerupCallback(self)
            if (m.powerupType == 'curse'):
                t = self._text.text
                n = len(t) 
                self._text.text = t[:n - 1]
            else: self._text.text += str(m.letter)
            t = self._text.text 
            completed = bs.getActivity().check4word(self.node,t)
            if completed: bs.gameTimer(500,self.delText)
            self.node.handleMessage("flash")
            if m.sourceNode.exists():
                m.sourceNode.handleMessage(bs.PowerupAcceptMessage())
            return True
        else: super(self.__class__, self).handleMessage(m)		
		
class NewPowerupMessage(object):
    def __init__(self,powerupType,sourceNode=bs.Node(None),letter='A'):
        self.sourceNode = sourceNode
        self.powerupType = powerupType
        self.letter = letter
		
class MyPowerup(bsPowerup.Powerup):
    def __init__(self,position=(0,1,0),powerupType='health',expire=True):
        bs.Actor.__init__(self)
        factory = self.getFactory()
        self.powerupType = powerupType;
        self.letter = 'A'
        self._powersGiven = False
        self.word = list(bs.getActivity()._chosedWord)

        if powerupType == 'health':
            tex = factory.texHealth
            self.letter = random.choice(self.word)#(self.letters)
        elif powerupType == 'curse':
            tex = factory.texCurse
            self.letter = 'Delete'
        else: raise Exception("invalid powerupType: "+str(powerupType))

        if len(position) != 3: raise Exception("expected 3 floats for position")
		
        self.node = bs.newNode('prop', delegate=self,attrs={'body':'box',
                               'position':position, 'model':factory.model,
                               'lightModel':factory.modelSimple,  'shadowSize':0.5,
                               'colorTexture':tex,'reflection':'powerup',
                               'reflectionScale':[1.0], 'materials':(factory.powerupMaterial,bs.getSharedObject('objectMaterial'))})
        curve = bs.animate(self.node,"modelScale",{0:0,140:1.6,200:1})
        bs.gameTimer(200,curve.delete)
        
        m = bs.newNode('math', owner=self.node, attrs={'input1': (0, 0.5, 0), 'operation': 'add'})
        self.node.connectAttr('position', m, 'input2')
        self._powText = bs.newNode('text',owner=self.node,attrs={'text':self.letter,'inWorld':True,'shadow':1.0,'maxWidth':40,
                                            'flatness':1.0,'color':(1,1,1) if powerupType == 'health' else (1,0,0),'scale':0.0,'hAlign':'center'})
        m.connectAttr('output', self._powText, 'position')
        bs.animate(self._powText, 'scale', {0: 0.0, 100: 0.02})	
		
        if expire:
            bs.gameTimer(defaultPowerupInterval-2500,bs.WeakCall(self._startFlashing))
            bs.gameTimer(defaultPowerupInterval-1000,bs.WeakCall(self.handleMessage,bs.DieMessage()))
			
    def handleMessage(self,m):
        if isinstance(m,_TouchedMessage):
            if not self._powersGiven:
                node = bs.getCollisionInfo("opposingNode")
                if node is not None and node.exists(): node.handleMessage(NewPowerupMessage(self.powerupType,sourceNode=self.node,letter=self.letter))
        else: super(self.__class__, self).handleMessage(m)

#############################################################

def bsGetAPIVersion():
    return 4

def bsGetGames():
    return [Spelling]

class Spelling(bs.TeamGameActivity):

    @classmethod
    def getName(cls):
        return 'Spell It'
    
    @classmethod
    def getDescription(cls,sessionType):
        return 'Complete the word letter peer letter'

    # we're currently hard-coded for one map..
    @classmethod
    def getSupportedMaps(cls,sessionType):
        return ['Football Stadium']

    @classmethod
    def getSettings(cls,sessionType):
        settings = [("Epic Mode",{'default':False}),("Score to Win Per Player",{'minValue':2,'default':3,'increment':1})]
        return settings
    
    # we support teams, free-for-all, and co-op sessions
    @classmethod
    def supportsSessionType(cls,sessionType):
        return True if (issubclass(sessionType,bs.TeamsSession)
                        or issubclass(sessionType,bs.FreeForAllSession)
                        or issubclass(sessionType,bs.CoopSession)) else False

    def __init__(self,settings):
        bs.TeamGameActivity.__init__(self,settings)
        if self.settings['Epic Mode']: self._isSlowMotion = True
        self.announcePlayerDeaths = True
        self._scoreBoard = bs.ScoreBoard()
        self._chosedWord = ['A','B','C','D','E','F','G','H','I','J','K','L','M',
                            'N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
		
        self._chosingSound = bs.getSound('scoreIncrease')
        self._chosedSound = bs.getSound('cashRegister2')
		
        self._words = ['BOMB','MELEE.','FLAG','TNT','PUCK',
                       'PLAY','BOTS', 'PUNCH','JUMP','PICK','RUN','NINJA',
                       'MEL','SPAZ','CURSE','SHIELD','BOX','SPEED','RACE',
                       'MINE','MAPS','MODS','TICKET','MAP']
        
    def onTransitionIn(self):
        bs.TeamGameActivity.onTransitionIn(self, music='ForwardMarch')

    def onBegin(self):
        bs.TeamGameActivity.onBegin(self)
        self._scoreToWin = self.settings['Score to Win Per Player']
        self._startPowerupDrops()
        self._updateScoreBoard()
		
        self._scoreSound = bs.getSound('dingSmall')
        self._unscoreSound = bs.getSound('error')
        self._cheerSound = bs.getSound("cheer")
		
        bs.gameTimer(3000,self.starChosingWord)
		
        self._choseText = bs.newNode('text',
                         attrs={'vAttach':'bottom', 'hAttach':'center',
                         'text':' ',
                         'maxWidth':150,  'hAlign':'center',
                         'vAlign':'center', 'shadow':1.0,
                         'flatness':1.0, 'color':(1,1,1),
                         'scale':1,'position':(0,70)})
		
    def onTeamJoin(self,team):
        team.gameData['score'] = 0
        if self.hasBegun(): self._updateScoreBoard()
       
    def spawnPlayer(self, player):
        if isinstance(self.getSession(), bs.TeamsSession):
            position = self.getMap().getStartPosition(player.getTeam().getID())
        else:
            position = self.getMap().getFFAStartPosition(self.players)
        angle = None
        name = player.getName()
        lightColor = bsUtils.getNormalizedColor(player.color)
        displayColor = bs.getSafeColor(player.color, targetIntensity=0.75)

        spaz = PlayerSpaz_Speller(color=player.color,
                             highlight=player.highlight,
                             character=player.character,
                             player=player)
        player.setActor(spaz)

        spaz.node.name = name
        spaz.node.nameColor = displayColor
        spaz.connectControlsToPlayer()
        self.scoreSet.playerGotNewSpaz(player, spaz)

        spaz.handleMessage(bs.StandMessage(position, angle if angle is not None else random.uniform(0, 360)))
        t = bs.getGameTime()
        bs.playSound(self._spawnSound, 1, position=spaz.node.position)
        light = bs.newNode('light', attrs={'color':lightColor})
        spaz.node.connectAttr('position', light, 'position')
        bsUtils.animate(light, 'intensity', {0:0, 250:1, 500:0})
        bs.gameTimer(500, light.delete)
		
    def printRandomWord(self):
        word = random.choice(self._words)
        self._name = bs.NodeActor(bs.newNode('text',
                         attrs={'vAttach':'bottom', 'hAttach':'center',
                         'text':word,
                         'maxWidth':100,  'hAlign':'center',
                         'vAlign':'center', 'shadow':1.0,
                         'flatness':1.0, 'color':(1,1,1),
                         'scale':2,'position':(0,30)}))
        return word
		
    def starChosingWord(self):
        self._chosedPlayer = None
        self._sound = bs.NodeActor(bs.newNode('sound',attrs={'sound':self._chosingSound,'volume':1.0}))
        self._wordEffect = bs.Timer(80,bs.WeakCall(self.printRandomWord),repeat=True)
        bs.gameTimer(3000,self.stopnChoseWord)
        self._choseText.text = 'Chosing word...'
        self._choseText.color =  (1,1,1)
		
    def stopnChoseWord(self):
        self._sound = None
        self._wordEffect = None
        bs.playSound(self._chosedSound)
        word = self.printRandomWord()
        self._chosedWord = word
        self._choseText.text = 'Spell it!'
        self._choseText.color =  (1,1,0)
		
    def check4word(self,player,playerText):
        if playerText.strip() == self._chosedWord:
            self.playerScores(player)
            return True

    def playerScores(self,p):
        try: player = p.getDelegate().getPlayer()
        except Exception: player = None
        if player.exists():
            if player.isAlive():       
                player.getTeam().gameData['score'] = max(0,player.getTeam().gameData['score']+1)
                bs.playSound(self._scoreSound)
                bs.gameTimer(600,self.starChosingWord)
                self._updateScoreBoard()

                if any(team.gameData['score'] >= self._scoreToWin for team in self.teams):
                    bs.playSound(self._cheerSound)
                    bs.gameTimer(500,self.endGame)       

    def _updateScoreBoard(self):
        for team in self.teams:
            self._scoreBoard.setTeamValue(team,team.gameData['score'],self._scoreToWin)		  

    def endGame(self):
        results = bs.TeamGameResults()
        for t in self.teams: results.setTeamScore(t,t.gameData['score'])
        self.end(results=results)
		
    def _startPowerupDrops(self):
        map = self.getMap().getName()
        self._powerupDropTimer = bs.Timer(500,bs.WeakCall(self._dropPowerups),repeat=True)
		
    def _dropPowerups(self,standardPoints=False,powerupType=None):
        x = random.randrange(-10,10)
        y = random.randrange(-5,5)
        pt = (x,1,y)
        self._flashMine(pt)
        bs.gameTimer(950,bs.Call(self._makeP,pt))
    
    def _makeP(self,pt):
        MyPowerup(position=pt,powerupType=self.getPowType()).autoRetain()		

    def _flashMine(self,pos):
        light = bs.newNode("light",
                           attrs={'position':pos,
                                  'color':(1,1,0.2),
                                  'radius':0.1,
                                  'heightAttenuated':False})
        bs.animate(light,"intensity",{0:0,100:1.0,200:0},loop=True)
        bs.gameTimer(1000,light.delete)
			
    def getPowType(self):
        powerups = ['health','curse','curse','health','health','health','health','health']
        return random.choice(powerups)
		
    def handleMessage(self,m):
        if isinstance(m,bs.PlayerSpazDeathMessage):
            bs.TeamGameActivity.handleMessage(self,m)
            player = m.spaz.getPlayer()
            self.respawnPlayer(player)
        else: bs.TeamGameActivity.handleMessage(self,m)