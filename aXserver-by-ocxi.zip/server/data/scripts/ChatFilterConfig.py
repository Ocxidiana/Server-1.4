blacklist = ['myr','punda','funda','thayoli','kandaroli','thaayoli','meir','koothi','poori','fuck','suck','punde','dick','cock','mother','asshole','boob','oomb','umfi','pussy','pulayadi','polayadi','vaanam'] #add words u want to block
kickSpammer = ['yes'] #select yes/no if u want to kick players or not
blockChats = ['no'] #Select yes/no to block chat for everyone(stay in peace)
credits = ['yes'] #give credit to the creator of mod - yes/no
