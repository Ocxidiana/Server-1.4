#Maded by Froshlee14
import bsSpaz, bs, random, bsUtils
from bsSpaz import _PunchHitMessage

class YouGotItSpaz(bs.PlayerSpaz):
    def newCurse(self):
        if not self._cursed:
            factory = self.getFactory()
            self._cursed = True
            bs.getActivity()._curPlay = self.getPlayer()
            time = self.getActivity()._curseTime
            self.node.curseDeathTime = bs.getGameTime() + time
            self._curseTimer = bs.Timer(time,bs.WeakCall(self.newCurseExplode))
            #bs.gameTimer(time,bs.WeakCall(self.newCurseExplode))
			
    def newCurseExplode(self,sourcePlayer=None):
        if sourcePlayer is None: sourcePlayer = bs.Player(None)
        
        if self._cursed and self.node.exists():
            self.shatter(extreme=True)
            self.handleMessage(bs.DieMessage())
            activity = self._activity()
            if activity:
                bs.Blast(position=self.node.position,
                         velocity=self.node.velocity,
                         blastRadius=3.0,blastType='normal',
                         sourcePlayer=sourcePlayer if sourcePlayer.exists() else self.sourcePlayer).autoRetain()
            self._cursed = False
	
    def handleMessage(self, m):
        if isinstance(m,bs.HitMessage):
            if not self.node.exists(): return
			
            try:
                if self.isAlive():
                    if m.sourcePlayer is not None:
                        if m.sourcePlayer.actor._cursed:
                            m.sourcePlayer.actor.node.curseDeathTime = 0
                            m.sourcePlayer.actor._cursed = False
                            m.sourcePlayer.actor._curseTimer = None
                            self.newCurse()
                            bs.playSound(bs.getSound('swip'))
            except Exception: pass
		    
            if self.node.invincible == True:
                bs.playSound(self.getFactory().blockSound,1.0,position=self.node.position)
                return True

            gameTime = bs.getGameTime()
            if self._lastHitTime is None or gameTime-self._lastHitTime > 1000:
                self._numTimesHit += 1
                self._lastHitTime = gameTime
            
            mag = m.magnitude * self._impactScale
            velocityMag = m.velocityMagnitude * self._impactScale

            damageScale = 0.22

            if self.shield is not None:
                if m.flatDamage: damage = m.flatDamage * self._impactScale
                else:
                    self.node.handleMessage("impulse",m.pos[0],m.pos[1],m.pos[2],
                                            m.velocity[0],m.velocity[1],m.velocity[2],
                                            mag,velocityMag,m.radius,1,m.forceDirection[0],m.forceDirection[1],m.forceDirection[2])
                    damage = damageScale * self.node.damage

                self.shieldHitPoints -= damage

                self.shield.hurt = 1.0 - float(self.shieldHitPoints)/self.shieldHitPointsMax
                maxSpillover = self.getFactory().maxShieldSpilloverDamage
                if self.shieldHitPoints <= 0:
                    self.shield.delete()
                    self.shield = None
                    bs.playSound(self.getFactory().shieldDownSound,1.0,position=self.node.position)
                    t = self.node.position
                    bs.emitBGDynamics(position=(t[0],t[1]+0.9,t[2]),
                                      velocity=self.node.velocity,
                                      count=random.randrange(20,30),scale=1.0,spread=0.6,chunkType='spark')

                else:
                    bs.playSound(self.getFactory().shieldHitSound,0.5,position=self.node.position)

                bs.emitBGDynamics(position=m.pos,
                                  velocity=(m.forceDirection[0]*1.0,
                                            m.forceDirection[1]*1.0,
                                            m.forceDirection[2]*1.0),
                                  count=min(30,5+int(damage*0.005)),scale=0.5,spread=0.3,chunkType='spark')

                if self.shieldHitPoints <= -maxSpillover:
                    leftoverDamage = -maxSpillover-self.shieldHitPoints
                    shieldLeftoverRatio = leftoverDamage/damage

                    mag *= shieldLeftoverRatio
                    velocityMag *= shieldLeftoverRatio
                else:
                    return True # good job shield!
            else: shieldLeftoverRatio = 1.0

            if m.flatDamage:
                damage = m.flatDamage * self._impactScale * shieldLeftoverRatio
            else:
                self.node.handleMessage("impulse",m.pos[0],m.pos[1],m.pos[2],
                                        m.velocity[0],m.velocity[1],m.velocity[2],
                                        mag,velocityMag,m.radius,0,m.forceDirection[0],m.forceDirection[1],m.forceDirection[2])

                damage = damageScale * self.node.damage
            self.node.handleMessage("hurtSound")

            if m.hitType == 'punch':
                pos = self.node.position
                self.onPunched(damage)
				
                if damage > 350:
                    bsUtils.showDamageCount('-'+str(int(damage/10))+"%",m.pos,m.forceDirection)

                if m.hitSubType == 'superPunch':
                    bs.playSound(self.getFactory().punchSoundStronger,1.0,
                                 position=self.node.position)

                if damage > 500:
                    sounds = self.getFactory().punchSoundsStrong
                    sound = sounds[random.randrange(len(sounds))]
                else: sound = self.getFactory().punchSound
                bs.playSound(sound,1.0,position=self.node.position)

                bs.emitBGDynamics(position=m.pos,
                                  velocity=(m.forceDirection[0]*0.5,
                                            m.forceDirection[1]*0.5,
                                            m.forceDirection[2]*0.5),
                                  count=min(10,1+int(damage*0.0025)),scale=0.3,spread=0.03);

                bs.emitBGDynamics(position=m.pos,
                                  chunkType='sweat',
                                  velocity=(m.forceDirection[0]*1.3,
                                            m.forceDirection[1]*1.3+5.0,
                                            m.forceDirection[2]*1.3),
                                  count=min(30,1+int(damage*0.04)),
                                  scale=0.9,
                                  spread=0.28);
                hurtiness = damage*0.003
                punchPos = (m.pos[0]+m.forceDirection[0]*0.02,
                            m.pos[1]+m.forceDirection[1]*0.02,
                            m.pos[2]+m.forceDirection[2]*0.02)
                flashColor = (1.0,0.8,0.4)
                light = bs.newNode("light",
                                   attrs={'position':punchPos,
                                          'radius':0.12+hurtiness*0.12,
                                          'intensity':0.3*(1.0+1.0*hurtiness),
                                          'heightAttenuated':False,
                                          'color':flashColor})
                bs.gameTimer(60,light.delete)


                flash = bs.newNode("flash",
                                   attrs={'position':punchPos,
                                          'size':0.17+0.17*hurtiness,
                                          'color':flashColor})
                bs.gameTimer(60,flash.delete)

            if m.hitType == 'impact':
                bs.emitBGDynamics(position=m.pos,
                                  velocity=(m.forceDirection[0]*2.0,
                                            m.forceDirection[1]*2.0,
                                            m.forceDirection[2]*2.0),
                                  count=min(10,1+int(damage*0.01)),scale=0.4,spread=0.1);
                
            if self.hitPoints > 0:
                if m.hitType == 'impact' and damage > self.hitPoints:
                    newDamage = max(damage-200,self.hitPoints-10)
                    damage = newDamage

                self.node.handleMessage("flash")
                if damage > 0.0 and self.node.holdNode.exists():
                    self.node.holdNode = bs.Node(None)
                self.hitPoints -= damage
                self.node.hurt = 1.0 - float(self.hitPoints)/self.hitPointsMax
                if self.frozen and (damage > 200 or self.hitPoints <= 0):
                    self.shatter()
                elif self.hitPoints <= 0:
                    self.node.handleMessage(bs.DieMessage(how='impact'))

            if self.hitPoints <= 0:
                damageAvg = self.node.damageSmoothed * damageScale
                if damageAvg > 1000:
                    self.shatter()
        else:super(self.__class__, self).handleMessage(m)
		
class Icon(bs.Actor):
        
    def __init__(self,player,position,scale,showLives=True,showDeath=True,
                 nameScale=1.0,nameMaxWidth=115.0,flatness=1.0,shadow=1.0):
        bs.Actor.__init__(self)

        self._player = player
        self._showLives = showLives
        self._showDeath = showDeath
        self._nameScale = nameScale

        self._outlineTex = bs.getTexture('characterIconMask')
        
        icon = player.getIcon()
        self.node = bs.newNode('image',
                               owner=self,
                               attrs={'texture':icon['texture'],
                                      'tintTexture':icon['tintTexture'],
                                      'tintColor':icon['tintColor'],
                                      'vrDepth':400,
                                      'tint2Color':icon['tint2Color'],
                                      'maskTexture':self._outlineTex,
                                      'opacity':1.0,
                                      'absoluteScale':True,
                                      'attach':'bottomCenter'})
        self._nameText = bs.newNode('text',
                                    owner=self.node,
                                    attrs={'text':bs.Lstr(value=player.getName()),
                                           'color':bs.getSafeColor(player.getTeam().color),
                                           'hAlign':'center',
                                           'vAlign':'center',
                                           'vrDepth':410,
                                           'maxWidth':nameMaxWidth,
                                           'shadow':shadow,
                                           'flatness':flatness,
                                           'hAttach':'center',
                                           'vAttach':'bottom'})
        if self._showLives:
            self._livesText = bs.newNode('text',
                                         owner=self.node,
                                         attrs={'text':'x0',
                                                'color':(1,1,0.5),
                                                'hAlign':'left',
                                                'vrDepth':430,
                                                'shadow':1.0,
                                                'flatness':1.0,
                                                'hAttach':'center',
                                                'vAttach':'bottom'})
        self.setPositionAndScale(position,scale)

    def setPositionAndScale(self,position,scale):
        self.node.position = position
        self.node.scale = [70.0*scale]
        self._nameText.position = (position[0],position[1]+scale*52.0)
        self._nameText.scale = 1.0*scale*self._nameScale
        if self._showLives:
            self._livesText.position = (position[0]+scale*10.0,position[1]-scale*43.0)
            self._livesText.scale = 1.0*scale

    def updateForLives(self):
        if self._player.exists():
            lives = self._player.gameData['lives']
        else: lives = 0
        if self._showLives:
            if lives > 0: self._livesText.text = 'x'+str(lives-1)
            else: self._livesText.text = ''
        if lives == 0:
            self._nameText.opacity = 0.2
            self.node.color = (0.7,0.3,0.3)
            self.node.opacity = 0.2
        
    def handlePlayerSpawned(self):
        if not self.node.exists(): return
        self.node.opacity = 1.0
        self.updateForLives()

    def handlePlayerDied(self):
        if not self.node.exists(): return
        if self._showDeath:
            bs.animate(self.node,'opacity',{0:1.0,50:0.0,100:1.0,150:0.0,200:1.0,250:0.0,
                                            300:1.0,350:0.0,400:1.0,450:0.0,500:1.0,550:0.2})
            lives = self._player.gameData['lives']
            if lives == 0: bs.gameTimer(600,self.updateForLives)

def bsGetAPIVersion():
    return 4

def bsGetGames():
    return [GotItGame]
		
class GotItGame(bs.TeamGameActivity):

    @classmethod
    def getName(cls):
        return 'You got it'

    @classmethod
    def getDescription(cls,sessionType):
        return 'Pass the curse'
		
    @classmethod
    def getScoreInfo(cls):
        return {'scoreName':'Survived',
                'scoreType':'seconds',
                'noneIsWinner':True}

    @classmethod
    def supportsSessionType(cls,sessionType):
        return True if (issubclass(sessionType,bs.TeamsSession)
                        or issubclass(sessionType,bs.FreeForAllSession)) else False

    @classmethod
    def getSupportedMaps(cls,sessionType):
        return bs.getMapsSupportingPlayType("keepAway")

    @classmethod
    def getSettings(cls,sessionType):
        return [("Time Limit",{'choices':[('None',0),('1 Minute',60),
                                        ('2 Minutes',120),('5 Minutes',300),
                                        ('10 Minutes',600),('20 Minutes',1200)],'default':0}),
                 ("Lives Per Player",{'default':1,'minValue':1,'maxValue':10,'increment':1}),
                ("Respawn Times",{'choices':[('Shorter',0.25),('Short',0.5),('Normal',1.0)],'default':1.0}),
                ("Curse Time (seconds)",{'minValue':8,'default':12,'increment':1,'maxValue':30}),
                ("Epic Mode",{'default':False})]


    def __init__(self,settings):
        bs.TeamGameActivity.__init__(self,settings)
        if self.settings['Epic Mode']: self._isSlowMotion = True
		
        self._curseTime = self.settings['Curse Time (seconds)']*1000
        self._chosingSound = bs.getSound('warnBeep')
        self._chosedSound = bs.getSound('cashRegister')
        self._curPlay = None
		
        self.announcePlayerDeaths = True

    def onTransitionIn(self):
        bs.TeamGameActivity.onTransitionIn(self, music='Epic' if self.settings['Epic Mode'] else 'Survival')
        self._startGameTime = bs.getGameTime()
		
    def onTeamJoin(self,team):
        team.gameData['survivalSeconds'] = None
        team.gameData['spawnOrder'] = []
		
    def onPlayerJoin(self, player):

        # no longer allowing mid-game joiners here... too easy to exploit
        if self.hasBegun():
            player.gameData['lives'] = 0
            player.gameData['icons'] = []
            # make sure our team has survival seconds set if they're all dead
            # (otherwise blocked new ffa players would be considered 'still alive' in score tallying)
            if self._getTotalTeamLives(player.getTeam()) == 0 and player.getTeam().gameData['survivalSeconds'] is None:
                player.getTeam().gameData['survivalSeconds'] = 0
            bs.screenMessage(bs.Lstr(resource='playerDelayedJoinText',subs=[('${PLAYER}',player.getName(full=True))]),color=(0,1,0))
            return
        
        player.gameData['lives'] = self.settings['Lives Per Player']

        # create our icon and spawn
        player.gameData['icons'] = [Icon(player,position=(0,50),scale=0.8)]
        if player.gameData['lives'] > 0:
            self.spawnPlayerSpaz(player)

        # dont waste time doing this until begin
        if self.hasBegun():
            self._updateIcons()

    def onBegin(self):
        bs.TeamGameActivity.onBegin(self)
        self.setupStandardTimeLimit(self.settings['Time Limit'])
        bs.gameTimer(3000,self.starChosingPlayer)
		
        self._choseText = bs.newNode('text',
                         attrs={'vAttach':'bottom', 'hAttach':'left',
                         'text':' ','opacity':1.0,
                         'maxWidth':150,  'hAlign':'center',
                         'vAlign':'center', 'shadow':1.0,
                         'flatness':1.0, 'color':(1,1,1),
                         'scale':1,'position':(50,155)})
						 
        if (isinstance(self.getSession(),bs.TeamsSession)
            and self.settings['Balance Total Lives']
            and len(self.teams[0].players) > 0
            and len(self.teams[1].players) > 0):
            if self._getTotalTeamLives(self.teams[0]) < self._getTotalTeamLives(self.teams[1]):
                lesserTeam = self.teams[0]
                greaterTeam = self.teams[1]
            else:
                lesserTeam = self.teams[1]
                greaterTeam = self.teams[0]
            addIndex = 0
            while self._getTotalTeamLives(lesserTeam) < self._getTotalTeamLives(greaterTeam):
                lesserTeam.players[addIndex].gameData['lives'] += 1
                addIndex = (addIndex + 1) % len(lesserTeam.players)

        self._updateIcons()
        bs.gameTimer(1000, self._update, repeat=True)
		
    def _getTotalTeamLives(self,team):
        return sum(player.gameData['lives'] for player in team.players)
						 
    def onPlayerLeave(self,player):
        bs.TeamGameActivity.onPlayerLeave(self,player)
        if player == self._curPlay: self.starChosingPlayer()
		
        player.gameData['icons'] = None
        bs.gameTimer(0, self._updateIcons)
		

    def _updateIcons(self):
        # in free-for-all mode, everyone is just lined up along the bottom
        if isinstance(self.getSession(),bs.FreeForAllSession):
            count = len(self.teams)
            xOffs = 85
            x = xOffs*(count-1) * -0.5
            for i,team in enumerate(self.teams):
                if len(team.players) == 1:
                    player = team.players[0]
                    for icon in player.gameData['icons']:
                        icon.setPositionAndScale((x,30),0.7)
                        icon.updateForLives()
                    x += xOffs
        # in teams mode we split up teams
        else:
            for team in self.teams:
                if team.getID() == 0:
                    x = -50
                    xOffs = -85
                else:
                    x = 50
                    xOffs = 85
                for player in team.players:
                    for icon in player.gameData['icons']:
                        icon.setPositionAndScale((x,30),0.7)
                        icon.updateForLives()
                    x += xOffs
		
    def getRandomPlayer(self):
        players = []
        for p in self.players:
            #if p.isAlive(): 
            players.append(p)
        return players
		
    def printRandomIcon(self):
        player = random.choice(self.getRandomPlayer())
        icon = player.getIcon()
        outlineTex = bs.getTexture('characterIconMask')
        texture = icon['texture']
        self._image = bs.NodeActor(bs.newNode('image',
                       attrs={'texture':texture,
                       'tintTexture':icon['tintTexture'],
                       'tintColor':icon['tintColor'],
                       'tint2Color':icon['tint2Color'],
                       'maskTexture':outlineTex,
                       'position':(50,80),'rotate':0,
                       'scale':(100,100), 'opacity':1.0,
                       'absoluteScale':True,'attach':'bottomLeft'}))
        bs.animate(self._image.node, 'rotate', {0: 0.0, 300: 360})	
        self._name = bs.NodeActor(bs.newNode('text',
                         attrs={'vAttach':'bottom', 'hAttach':'left',
                         'text':bs.Lstr(value=player.getName()),
                         'maxWidth':100,  'hAlign':'center',
                         'vAlign':'center', 'shadow':1.0,
                         'flatness':1.0, 'color':bs.getSafeColor(icon['tintColor']),
                         'scale':1,'position':(50,17),'opacity':1.0,}))
        return player
        
    def starChosingPlayer(self):
        if self.hasEnded(): return
        self._sound = bs.NodeActor(bs.newNode('sound',attrs={'sound':self._chosingSound,'volume':1.0}))
        self._logoEffect = bs.Timer(80,bs.WeakCall(self.printRandomIcon),repeat=True)
        bs.gameTimer(2000,self.stopnChosePlayer)
        self._choseText.text = 'Chosing player...'
        self._choseText.color =  (1,1,1)
		
    def stopnChosePlayer(self):
        self._sound = None
        self._logoEffect = None
        bs.playSound(self._chosedSound)
        player = self.printRandomIcon()
        player.actor.newCurse()
        self._choseText.text = 'You got it!'
        self._choseText.color =  (1,1,0)
        bs.animate(self._image.node, 'opacity', {0: 1.0, 3000:0.0})	
        bs.animate(self._choseText, 'opacity', {0: 1.0, 3000:0.0})	
        bs.animate(self._name.node, 'opacity', {0: 1.0, 3000:0.0})	

    def spawnPlayerSpaz(self,player,position=(0,0,0),angle=None):
        position = self.getMap().getFFAStartPosition(self.players)
        name = player.getName()
        color = player.color
        highlight = player.highlight
        lightColor = bsUtils.getNormalizedColor(color)
        displayColor = bs.getSafeColor(color,targetIntensity=0.75)

        spaz = YouGotItSpaz(color=color, highlight=highlight, character=player.character, player=player)
        player.setActor(spaz)
                         
        spaz.node.name = name
        spaz.node.nameColor = displayColor
        spaz.connectControlsToPlayer()
        spaz.hitPoints = -1
                
        self.scoreSet.playerGotNewSpaz(player,spaz)
        spaz.handleMessage(bs.StandMessage(position,angle if angle is not None else random.uniform(0,360)))
        t = bs.getGameTime()
        bs.playSound(self._spawnSound,1,position=spaz.node.position)
        light = bs.newNode('light',attrs={'color':lightColor})
        spaz.node.connectAttr('position',light,'position')
        bsUtils.animate(light,'intensity',{0:0,250:1,500:0})
        bs.gameTimer(500,light.delete)
		
        bs.gameTimer(300,bs.Call(self._printLives,player))
        for icon in player.gameData['icons']:
            icon.handlePlayerSpawned()
        return spaz
		
    def _printLives(self,player):
        if not player.exists() or not player.isAlive(): return
        try: pos = player.actor.node.position
        except Exception,e:
            print 'EXC getting player pos in bsElim',e
            return
        bs.PopupText('x'+str(player.gameData['lives']-1),color=(1,1,0,1),
                           offset=(0,-0.8,0),randomOffset=0.0,scale=1.8,position=pos).autoRetain()

    def handleMessage(self,m):
        if isinstance(m,bs.PlayerSpazDeathMessage):
            bs.TeamGameActivity.handleMessage(self,m)
            player = m.spaz.getPlayer()
            if player.actor._cursed: self.starChosingPlayer()
			
            player.gameData['lives'] -= 1
            if player.gameData['lives'] < 0:
                player.gameData['lives'] = 0

            for icon in player.gameData['icons']:
                icon.handlePlayerDied()

            if player.gameData['lives'] == 0:
                if self._getTotalTeamLives(player.getTeam()) == 0:
                    player.getTeam().gameData['survivalSeconds'] = (bs.getGameTime()-self._startGameTime)/1000
            else:
                self.respawnPlayer(player,self.settings['Respawn Times'])
        else: bs.TeamGameActivity.handleMessage(self,m)

    def _update(self):
        if len(self._getLivingTeams()) < 2:
            self._roundEndTimer = bs.Timer(500,self.endGame)

    def _getLivingTeams(self):
        return [team for team in self.teams if len(team.players) > 0 and any(player.gameData['lives'] > 0 for player in team.players)]

    def endGame(self):
        if self.hasEnded(): return
        self._sound = None
        self._logoEffect = None
        results = bs.TeamGameResults()
        self._vsText = None # kill our 'vs' if its there
        for team in self.teams:
            results.setTeamScore(team, team.gameData['survivalSeconds'])
        self.end(results=results)