#Minigame by Froshlee14
import bs, bsSpaz, random, bsBomb, bsPowerup
from bsSpaz import *
from bsSpaz import _BombDiedMessage
from bsBomb import ImpactMessage

class NewPlayerSpaz(bs.PlayerSpaz):

    def __init__(self, color=(1, 1, 1), highlight=(0.5, 0.5, 0.5),
                 character="Spaz", player=None, powerupsExpire=True):

        if player is None: player = bs.Player(None)
        
        Spaz.__init__(self, color=color, highlight=highlight, character=character, sourcePlayer=player,
                      startInvincible=True, powerupsExpire=powerupsExpire,canAcceptPowerups=False)
        self.lastPlayerAttackedBy = None 
        self.lastAttackedTime = 0
        self.lastAttackedType = None
        self.heldCount = 0
        self.lastPlayerHeldBy = None 
        self._player = player

        if player.exists():
            playerNode = bs.getActivity()._getPlayerNode(player)
            self.node.connectAttr('torsoPosition', playerNode, 'position')
            

    def handleMessage(self, m):
        if isinstance(m, _BombDiedMessage):
            self.bombCount += 1
            self.checkAvalibleBombs()
        else:  super(self.__class__, self).handleMessage(m)
            

    def checkAvalibleBombs(self):
        if self.exists():
            if self.bombCount >= 1:
                if not self.node.holdNode.exists():
                    self.onBombPress()
                    self.onBombRelease()

    def startBombChecking(self):
        self.checkAvalibleBombs()
        self._bombCheckTimer = bs.gameTimer(500, bs.WeakCall(self.checkAvalibleBombs), repeat=True)


    def dropBomb(self):
        if (self.landMineCount <= 0 and self.bombCount <= 0) or self.frozen:
            return
        p = self.node.positionForward
        v = self.node.velocity

        if self.landMineCount > 0:
            droppingBomb = False
            self.setLandMineCount(self.landMineCount-1)
            bombType = 'landMine'
        else:
            droppingBomb = True
            bombType = self.bombType

        bomb = myBomb(pos=(p[0], p[1] - 0.0, p[2]),sourceP=self.sourcePlayer).autoRetain()

        if droppingBomb:
            self.bombCount -= 1
            bomb.node.addDeathAction(bs.WeakCall(self.handleMessage,
                                                 _BombDiedMessage()))
        self._pickUp(bomb.node)

        for c in self._droppedBombCallbacks: c(self, bomb)
        
        return bomb

class myBomb(bs.Bomb):
    def __init__(self,pos,sourceP):
        bs.Bomb.__init__(self,position=pos,bombType='landMine',sourcePlayer=sourceP)

        pam = bs.Powerup.getFactory().powerupAcceptMaterial
        materials = getattr(self.node,'materials')

        if not pam in materials:
            setattr(self.node,'materials',materials + (pam,))
        materials = getattr(self.node,'materials')
		
        self.groundMaterial = bs.Material()
        self.groundMaterial.addActions(
            conditions=(('weAreOlderThan', 200),
                        'and', ('theyAreOlderThan',200),
                        'and', ('evalColliding',),
                        'and', (('theyHaveMaterial',
                                 bs.getSharedObject('footingMaterial')))),
            actions=(('message','ourNode','atConnect',ImpactMessage())))

		
        bs.gameTimer(250,bs.WeakCall(self._addMaterial,self.groundMaterial))

    def handleMessage(self,m):
        if isinstance(m, bs.HitMessage):
            return True
        if isinstance(m, bs.PowerupMessage):
            for player in self.getActivity().players:
                if player == self.sourcePlayer:
                    pos = self.node.position
                    p = (pos[0],pos[1]-2,pos[2])
                    if m.powerupType == 'health':
                        player.getTeam().gameData['score'] += 1
                        bsUtils.PopupText('+1',color=(0,1,0),scale=2,position=p).autoRetain()
                    elif m.powerupType == 'shield':
                        player.getTeam().gameData['score'] += 2
                        bsUtils.PopupText('+2',color=(1,1,0),scale=2,position=p).autoRetain()
                    else:
                        player.getTeam().gameData['score'] -= 1
                        bsUtils.PopupText('-1',color=(1,0,0),scale=2,position=p).autoRetain()
						
                    self.getActivity()._updateScoreBoard()
                    self.getActivity().playerScores()
                    self.arm()
            if m.sourceNode.exists():
                m.sourceNode.handleMessage(bs.PowerupAcceptMessage())
        else:
            super(self.__class__, self).handleMessage(m)
			
    def arm(self):

        if not self.node.exists(): return
        factory = self.getFactory()
        if self.bombType == 'landMine':
            self.textureSequence = \
                bs.newNode('textureSequence', owner=self.node, attrs={ 'rate':30,
                    'inputTextures':(factory.landMineLitTex,factory.landMineTex)})
            bs.gameTimer(500,self.textureSequence.delete)
   
        self.textureSequence.connectAttr('outputTexture',self.node, 'colorTexture')
        bs.playSound(factory.activateSound, 0.5, position=self.node.position)
			
class MyPowerup(bs.Powerup):
    def __init__(self,pos,type='tripleBombs'):
        bs.Powerup.__init__(self,position=pos,powerupType=type,expire=False)
        defaultPowerupInterval = 6200
        bs.gameTimer(defaultPowerupInterval-1000,bs.WeakCall(self.handleMessage, bs.DieMessage()))


def bsGetAPIVersion():
    return 4

def bsGetGames():
    return [Catch]

class Catch(bs.TeamGameActivity):

    @classmethod
    def getName(cls):
        return 'Powers Fall'
    
    @classmethod
    def getDescription(cls,sessionType):
        return ' Catch powerups and get points'

    @classmethod
    def getSupportedMaps(cls,sessionType):
        return ['Courtyard']

    @classmethod
    def getSettings(cls,sessionType):
        return [("Epic Mode",{'default':False}),("Score to Win Per Player",{'minValue':10,'default':20,'increment':1}),
                ("Negative Points",{'default':True})]
    
    @classmethod
    def supportsSessionType(cls,sessionType):
        return True if (issubclass(sessionType,bs.TeamsSession)
                        or issubclass(sessionType,bs.FreeForAllSession)
                        or issubclass(sessionType,bs.CoopSession)) else False

    def __init__(self,settings):
        bs.TeamGameActivity.__init__(self,settings)
        if self.settings['Epic Mode']: self._isSlowMotion = True
        self.announcePlayerDeaths = True
        self._prevChosenPowerup = 'health'
        self._scoreBoard = bs.ScoreBoard()
        self._chosenPowerup = 'health'
        self._powerupSpread = (4,4)
        
    def onTransitionIn(self):
        bs.TeamGameActivity.onTransitionIn(self, music='ForwardMarch')
        self._scoreToWin = self.settings['Score to Win Per Player']
		
        self._powerupCenter = self.getMap().defs.points['flagDefault']
		
        bs.getSharedObject('globals').areaOfInterestBounds = (0,4,-15,1,1,1)

    def onBegin(self):
        bs.TeamGameActivity.onBegin(self)
        self._startPowerupDrops()
        self._updateScoreBoard()
        
        self._scoreSound = bs.getSound('dingSmall')
        self._cheerSound = bs.getSound("cheer")
		
    def onTeamJoin(self,team):
        team.gameData['score'] = 0
        if self.hasBegun(): self._updateScoreBoard()
       
    def spawnPlayer(self, player):
        position = (self._powerupCenter[0]+random.uniform(-1.5,1.5),self._powerupCenter[1],self._powerupCenter[2]+random.uniform(-1.5,1.5))
        angle = None
        name = player.getName()
        lightColor = bsUtils.getNormalizedColor(player.color)
        displayColor = bs.getSafeColor(player.color, targetIntensity=0.75)

        spaz = NewPlayerSpaz(color=player.color,  highlight=player.highlight,
                                character=player.character, player=player)
        player.setActor(spaz)

        if isinstance(self.getSession(), bs.CoopSession) and self.getMap().getName() in ['Courtyard', 'Tower D']:
            mat = self.getMap().preloadData['collideWithWallMaterial']
            spaz.node.materials += (mat,)
            spaz.node.rollerMaterials += (mat,)

        spaz.node.name = name
        spaz.node.nameColor = displayColor
        spaz.connectControlsToPlayer(enableBomb=False,enablePickUp=False,enablePunch=False,enableJump=False)
        self.scoreSet.playerGotNewSpaz(player, spaz)

        spaz.handleMessage(bs.StandMessage(position, angle if angle is not None else random.uniform(0, 360)))
        t = bs.getGameTime()
        bs.playSound(self._spawnSound, 1, position=spaz.node.position)
        light = bs.newNode('light', attrs={'color':lightColor})
        spaz.node.connectAttr('position', light, 'position')
        bsUtils.animate(light, 'intensity', {0:0, 250:1, 500:0})
        bs.gameTimer(500, light.delete)
        
        bs.gameTimer(1000, bs.WeakCall(spaz.startBombChecking))

    def handleMessage(self,m):
        if isinstance(m,bs.PlayerSpazDeathMessage):
            bs.TeamGameActivity.handleMessage(self,m)
            player = m.spaz.getPlayer()
            self.respawnPlayer(player)
        elif isinstance(m,bs.SpazBotDeathMessage):
            self._onSpazBotDied(m)
            bs.TeamGameActivity.handleMessage(self,m)
        else:
            bs.TeamGameActivity.handleMessage(self,m)
            
    def playerScores(self):
        if any(team.gameData['score'] >= self._scoreToWin for team in self.teams):
            bs.playSound(self._cheerSound)
            bs.gameTimer(500,self.endGame)       

    def _updateScoreBoard(self):
        for team in self.teams:
            self._scoreBoard.setTeamValue(team,team.gameData['score'],self._scoreToWin)          

    def endGame(self):
        results = bs.TeamGameResults()
        for t in self.teams: results.setTeamScore(t,t.gameData['score'])
        self.end(results=results)
        
    def _startPowerupDrops(self):
        map = self.getMap().getName()
        self._powerupDropTimer = bs.Timer(500,bs.WeakCall(self._dropPowerups),repeat=True)
        
    def _dropPowerups(self,standardPoints=False,powerupType=None):
        pt = (random.randrange(-3,4),self._powerupCenter[1]+8,random.randrange(-5,2))
        bs.gameTimer(950,bs.Call(self._makeP,pt))
    
    def _makeP(self,pt):
        b = MyPowerup(pos=pt,type=self.getPowType()).autoRetain()
        pos = b.node.position
        bsUtils.animateArray(b.node,'position',3,{0:b.node.position,5500:(pos[0],pos[1]-8,pos[2])})	
            
    def getPowType(self):
        powerups = ['shield','health','health','health','health']
        if self.settings['Negative Points']:
            for i in range(5):
                powerups.append('curse')
        return random.choice(powerups)
		
    def showInfo(playGong=True):
        activity = bs.getActivity()
        name = activity.getInstanceDisplayString()
        bsUtils.ZoomText(name,maxWidth=800,lifespan=2500,jitter=2.0,position=(0,0),flash=False,
                         color=(0.93*1.25,0.9*1.25,1.0*1.25),trailColor=(0.15,0.05,1.0,0.0)).autoRetain()
        if playGong: bs.gameTimer(200,bs.Call(bs.playSound,bs.getSound('gong')))
		
        desc = activity.getInstanceDescription()
        if type(desc) in [unicode,str]: desc = [desc] # handle simple string case
        if type(desc[0]) not in [unicode,str]: raise Exception("Invalid format for instance description")
        subs = []
        for i in range(len(desc)-1):
            subs.append(('${ARG'+str(i+1)+'}',str(desc[i+1])))
        translation = bs.Lstr(translate=('gameDescriptions',desc[0]),subs=subs)

        if ('Epic Mode' in activity.settings and activity.settings['Epic Mode']):
            translation = bs.Lstr(resource='epicDescriptionFilterText',subs=[('${DESCRIPTION}',translation)])

        vr = bs.getEnvironment()['vrMode']
        d = bs.newNode('text',
                       attrs={'vAttach':'center',
                              'hAttach':'center',
                              'hAlign':'center',
                              'color':(1,1,1,1),
                              'shadow':1.0 if vr else 0.5,
                              'flatness':1.0 if vr else 0.5,
                              'vrDepth':-30,
                              'position':(0,80),
                              'scale':1.2,
                              'maxWidth':700,
                              'text':translation})
        c = bs.newNode("combine",owner=d,attrs={'input0':1.0,'input1':1.0,'input2':1.0,'size':4})
        c.connectAttr('output',d,'color')
        keys = {500:0,1000:1.0,2500:1.0,4000:0.0}
        bsUtils.animate(c,"input3",keys)
        bs.gameTimer(4000,d.delete)