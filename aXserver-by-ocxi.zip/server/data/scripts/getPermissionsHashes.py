adminHashes = []
vipHashes = []
banlist = {}
topperslist = []
effectCustomers = {}
customlist = {}
ownerHashes = ['pb-IF4MUXYpPQ==']
coownerHashes = []
surroundingObjectEffect = []
sparkEffect = ['pb-IF4MUXYpPQ==']
smokeEffect = []
scorchEffect = [] 
distortionEffect = []
glowEffect = [] 
iceEffect=[]
slimeEffect = []
metalEffect = []
dragonHashes = []
customtagHashes=[]
ocxitag=['pb-IF4MUXYpPQ==']

#donot change the order of the list
#to enable/disable commands and effects for top 5 players goto settings.py

