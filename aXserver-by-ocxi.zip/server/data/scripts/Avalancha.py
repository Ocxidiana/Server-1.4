#Made by Froshlee14
import bs, bsSpaz, random
from bsSpaz import _PunchHitMessage

def bsGetAPIVersion():
    return 4

def bsGetGames():
    return [AvalanchaGame]

class PascalBot(bsSpaz.ToughGuyBot):
    color=(0,0,3)
    highlight=(0.2,0.2,1)
    character = 'Pascal'
    bouncy = True
    punchiness = 0.8

    def handleMessage(self,m):
        if isinstance(m, _PunchHitMessage):
            node = bs.getCollisionInfo("opposingNode")
            try: node.handleMessage(bs.FreezeMessage())
            except Exception: print('Cant freeze')
            bs.playSound(bs.getSound('freeze'))
            super(self.__class__, self).handleMessage(m)
        elif isinstance(m, bs.FreezeMessage):pass
        else: super(self.__class__, self).handleMessage(m)
	
class AvalanchaGame(bs.TeamGameActivity):

    @classmethod
    def getName(cls):
        return 'Avalancha'

    @classmethod
    def getScoreInfo(cls):
        return {'scoreName':'Survived',
                'scoreType':'milliseconds',
                'scoreVersion':'B'}
    
    @classmethod
    def getDescription(cls,sessionType):
        return 'No te congeles'

    @classmethod
    def getSupportedMaps(cls,sessionType):
        return ['Tip Top']

    @classmethod
    def getSettings(cls,sessionType):
        return [("Epic Mode",{'default':False}),
                ("Dificultad",{'minValue':1,'maxValue':3,'default':1,'increment':1})]

    @classmethod
    def supportsSessionType(cls,sessionType):
        return True if (issubclass(sessionType,bs.TeamsSession)
                        or issubclass(sessionType,bs.FreeForAllSession)
                        or issubclass(sessionType,bs.CoopSession)) else False

    def __init__(self,settings):
        bs.TeamGameActivity.__init__(self,settings)
        if self.settings['Epic Mode']: self._isSlowMotion = True
        self.announcePlayerDeaths = True
        self._lastPlayerDeathTime = None

    def onTransitionIn(self):
        bs.TeamGameActivity.onTransitionIn(self, music='Epic' if self.settings['Epic Mode'] else 'Survival')
        bs.getSharedObject('globals').tint = (0.5,0.5,1)
        self.iceMaterial = bs.Material()
        self.iceMaterial.addActions(actions=('modifyPartCollision','friction',0.18))
        bs.getActivity().getMap().node.materials = [bs.getSharedObject('footingMaterial'),self.iceMaterial]
        bs.getActivity().getMap().bottom.color = bs.getActivity().getMap().node.color= (1,1,1.2)
        bs.getActivity().getMap().bottom.reflection = bs.getActivity().getMap().node.reflection = 'soft'
        bs.getActivity().getMap().bottom.reflectionScale = bs.getActivity().getMap().node.reflectionScale = [1.2]
		
    def onPlayerJoin(self, player):
        if self.hasBegun():
            bs.screenMessage(
                bs.Lstr(
                    resource='playerDelayedJoinText',
                    subs=[('${PLAYER}', player.getName(full=True))]),
                color=(0, 1, 0))
            player.gameData['deathTime'] = self._timer.getStartTime()
            return
        self.spawnPlayer(player)

    def onPlayerLeave(self, player):
        bs.TeamGameActivity.onPlayerLeave(self, player)
        self._checkEndGame()

    def onBegin(self):
        bs.TeamGameActivity.onBegin(self)
        if self.settings['Dificultad'] == 1: self._meteorTime = 700
        elif self.settings['Dificultad'] == 2: self._meteorTime = 500
        else: self._meteorTime = 300
        bs.gameTimer(4000,self.start)
        self._bots = bs.BotSet()
		
        self._timer = bs.OnScreenTimer()
        self._timer.start()
        
    def spawnPlayer(self,player):
        spaz = self.spawnPlayerSpaz(player)
        spaz.connectControlsToPlayer(enablePunch=False,
                                     enableBomb=False,
                                     enablePickUp=False)
        spaz.playBigDeathSound = True

    def handleMessage(self,m):
        if isinstance(m,bs.PlayerSpazDeathMessage):
            bs.TeamGameActivity.handleMessage(self,m)
            deathTime = bs.getGameTime()
            m.spaz.getPlayer().gameData['deathTime'] = deathTime
            if isinstance(self.getSession(),bs.CoopSession):
                bs.pushCall(self._checkEndGame)
                self._lastPlayerDeathTime = deathTime
            else: bs.gameTimer(1000,self._checkEndGame)
        else:  bs.TeamGameActivity.handleMessage(self,m)

    def _checkEndGame(self):
        livingTeamCount = 0
        for team in self.teams:
            for player in team.players:
                if player.isAlive():
                    livingTeamCount += 1
                    break
        if isinstance(self.getSession(),bs.CoopSession):
            if livingTeamCount <= 0: self.endGame()
        else:
            if livingTeamCount <= 1: self.endGame()
			
    def start(self):
        bs.gameTimer(self.getTime(),bs.Call(self._dropBombCluster),repeat=True)
        bs.gameTimer(6000,bs.Call(self._decTime),repeat=True)
        
    def _dropBombCluster(self):
        delay = 0
        for i in range(random.randrange(1,3)):
            pos = bs.getActivity().getMap().defs.points['flagDefault']
            pos = (pos[0],pos[1]+0.4,pos[2])
            vel = (random.randrange(-4,4),7.0,random.randrange(0,4))
            bs.gameTimer(delay,bs.Call(self._dropBomb,pos,vel))
            delay += 100

    def getTime(self):
        return self._meteorTime
		
    def _decTime(self):
        self._meteorTime -= 100
        if random.choice([0,0,1]) == 1:
            self._bots.spawnBot(PascalBot,pos= bs.getActivity().getMap().defs.points['flagDefault'],spawnTime=2000)
		
    def _dropBomb(self,position,velocity):
        b = bs.Bomb(position=position,velocity=velocity,bombType='ice').autoRetain()

    def endGame(self):
        curTime = bs.getGameTime()
        for team in self.teams:
            for player in team.players:
                if 'deathTime' not in player.gameData: player.gameData['deathTime'] = curTime+1
                score = (player.gameData['deathTime']-self._timer.getStartTime())/1000
                if 'deathTime' not in player.gameData: score += 50
                self.scoreSet.playerScored(player,score,screenMessage=False)
        self._timer.stop(endTime=self._lastPlayerDeathTime)
        results = bs.TeamGameResults()
        for team in self.teams:
            longestLife = 0
            for player in team.players:
                longestLife = max(longestLife,(player.gameData['deathTime'] - self._timer.getStartTime()))
            results.setTeamScore(team,longestLife)
        self.end(results=results)